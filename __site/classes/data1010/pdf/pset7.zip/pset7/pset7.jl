
using Random; Random.seed!(123)
using Plots
points = [rand(2) for i=1:200]
scatter([x for (x,y) in points],[y for (x,y) in points])

#---------------------------------------------------------------

using StatsBase
sorteddict = sort(countmap(countmatrix[:]))
xs = collect(keys(sorteddict))
ys = collect(values(sorteddict))
sticks(xs,ys/sum(ys),label="tally proportions")
poisson(λ,k) = exp(-λ)*λ^k/factorial(k)
sticks!(xs.+0.1,[poisson(λ,x) for x in xs],label="Poisson(2)")

#---------------------------------------------------------------

using StatsBase, Plots, FileIO, DataFrames
D = DataFrame(load("cities.csv"))
D[:Population]
tallydict = # you fill in this part
sticks(1:9,collect(values(tallydict)))

# --------------------------------------------------------------

using Statistics, LinearAlgebra
using Plots, StatsBase

struct PMF
    values
    masses
end

import Statistics: mean, var
mean(m::PMF) = m.values ⋅ m.masses
function var(m::PMF)
    μ = mean(m)
    (m.values .- μ).^2 ⋅ m.masses
end

"""
Return the distribution of the sum of 
an m-distributed random variable and an 
independent n-distributed random variable. 
"""
function convolve(m::PMF,n::PMF)
    D = Dict()
    for (value1,mass1) in zip(m.values,m.masses)
        for (value2,mass2) in zip(n.values,n.masses)
            newvalue = value1 + value2
            if newvalue in keys(D)
                D[newvalue] += mass1*mass2
            else
                D[newvalue] = mass1*mass2
            end
        end
    end
    sorteddict = sort(D)
    PMF(collect(keys(sorteddict)),collect(values(sorteddict)))
end

"""
Return the distribution of k independent 
m-distributed random variables
"""
function convolve(m::PMF,k::Integer)
    if k == 1
        m 
    else
        convolve(convolve(m,k-1),m)
    end
end

import Plots.plot
plot(m::PMF) = sticks(m.values,m.masses)
function compareplot(m::PMF) 
    plot(m)
    xs = range(-4,stop=4,length=1000)
    ys = [1/sqrt(2π)*exp(-x^2/2) for x in xs]
    plot!(xs,ys;xlims=(-4,4))
end
        
function standardize(m::PMF)
    PMF((m.values .- mean(m))./sqrt(var(m)),m.masses)
end

#--------------------------------------------------------------

m = PMF([0,1],[0.5,0.5])
compareplot(standardize(convolve(m,8)))

λ = 1
masses = [exp(-λ)*λ^k/factorial(k) for k=1:8]
masses /= sum(masses)
m = PMF(collect(1:8),masses)
